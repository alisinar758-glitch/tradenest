# Trade Nest — subscription platform (v2)

Next.js 15 + Prisma + PostgreSQL. Sells 30-day, per-MT5-account licenses ($10) for a gold EA. Persian guide: `guide-fa.md`.

## What v2 adds
- Fixed: broker symbols such as `XAUUSD.c` were rejected by `/api/license/validate` (prefix match now).
- Renewal in the last 7 days or after expiry; remaining days are kept and the same token keeps working.
- Email verification, password reset, login lockout, rate limiting, CSRF/Origin check, security headers, request-size limits.
- Admin 2FA (TOTP, required in production), audit log, token rotation, registration deletion, explorer links.
- Email notifications (Resend API, no extra dependency), protected EX5 download, legal pages.
- Docker Compose with automatic HTTPS (Caddy), backup script, health endpoint `/api/health`.
- `mt5/TradeNestLicense.mqh` for EA integration.

## Quick start (local)
1. Copy `.env.example` to `.env`; set `DATABASE_URL`, `AUTH_SECRET` (32+ chars), wallets.
2. `npm install && npx prisma migrate dev --name initial && npm run db:seed`
3. Set `ADMIN_EMAIL` / `ADMIN_PASSWORD` in `.env`, run `npm run admin:create`, then `npm run dev`.
4. Log in at `/login`, open `/admin/security` and enable 2FA (set `REQUIRE_ADMIN_2FA="false"` only for local testing).

Without `RESEND_API_KEY`, outgoing emails are printed in the server console (development only).
Production cookies are `Secure`, so test the production build over HTTPS.

## Production
See `guide-fa.md` (Docker, Caddy, backups). Run `npx prisma migrate dev --name initial` once locally and commit `prisma/migrations` if you prefer migrations over `db push`.

## Confirmed business rules
- Brand: Trade Nest; domain target: `tradenest.net` (not purchased/configured here).
- English website; product: Gold EA for XAUUSD on MT5.
- $10 per individual MT5 account for 30 days. Three accounts = $30 per 30 days.
- Each MT5 account must be separately submitted and manually IB-verified by an admin.
- Customer payments: USDT TRC20 or USDT BEP20; TXID review is manual.
- Customer support: website ticket system and Telegram `@justmoney2`.
- Customer registration: email and password.
- EA file is not publicly downloadable. The customer installs a protected EX5 through a controlled delivery process; source MQ5 is never provided.

## Original starter notes (see v2 list above for additions)
- Email/password registration and login; bcrypt password hashing and signed session cookie from the existing auth layer.
- Customer dashboard: add MT5 account, see manual IB verification status, create $10 order for an approved account, submit TXID, view order history, create support tickets.
- Admin dashboard at `/admin`: approve/reject IB accounts, approve/reject payments, reply to support tickets.
- One license per approved MT5 account and order; license expires after 30 days.
- License validation checks token hash, active status, expiry, XAUUSD symbol, MT5 login, exact broker server and approved account status.
- Wallets configured in `.env.example` from the addresses provided by the owner.
- EA file is not served from the public web directory.

## Important: what is NOT automated
**IB membership is manually reviewed.** An account number and server do not prove IB attribution. True automatic IB verification requires an official broker partner API/report integration and access granted by that broker. Until then, admin must check the broker's IB portal and approve/reject in `/admin`.

**Crypto payment is manually reviewed.** TXID submission alone is not proof of payment. Check correct network, token contract (USDT), exact amount, destination wallet, successful status, required confirmations and duplicate TXID on the appropriate explorer before approving. Do not approve based only on a screenshot.

**EA delivery is not included as a public download.** The protected EX5 should be distributed privately only after approval, using a secure controlled process. Do not put it in `public/`. The EA must send license token, MT5 login, exact broker server and symbol to `/api/license/validate`. Never ask customers for MT5 trading passwords or investor passwords.

An EX5 binary installed on a customer's own computer cannot be guaranteed impossible to copy or extract. Account binding and server-side license checks reduce unauthorized use but are not perfect DRM. If the requirement is that the customer must never possess an EA binary, the EA must run on a managed MT5 environment or supported broker/copy-trading infrastructure; that requires a separate technical and operational design.

## Run locally
Requirements: Node.js 20+, PostgreSQL.

1. Copy `.env.example` to `.env` and set `DATABASE_URL`, a random `AUTH_SECRET` of at least 32 characters, and wallet addresses.
2. `npm install`
3. `npx prisma generate`
4. `npx prisma migrate dev --name initial`
5. `npm run db:seed`
6. `npm run dev`
7. Open `http://localhost:3000`.

Register your own admin email as a normal account, then promote it using a trusted database console:

```sql
UPDATE "User" SET role='ADMIN' WHERE email='your-admin-email@example.com';
```

Then sign out/in and visit `/admin`. Never add public self-service admin promotion.

## Before public launch — required
- Run dependency audit, static analysis and full build; resolve any warnings/errors.
- Add email verification, password reset, login/register rate limiting, CAPTCHA/abuse controls, audit logs, admin MFA, session rotation and secure cookie review.
- Add CSRF/origin protection to all state-changing routes; validate deployment behind HTTPS; set strict security headers and request size limits.
- Add privacy policy, terms, risk disclosure, refund policy, and confirm legal/financial-services obligations for the target markets.
- Add official broker IB reporting integration if automatic verification is required. Never claim automatic IB validation until tested against a broker's authorized API.
- Verify wallet ownership and exact token contract/network. Consider chain-monitoring integration only after manual process is proven.
- Add admin actions for subscription extension/revocation and customer-visible license-token display/recovery. Current admin approval returns the token once; store/deliver it securely to the customer.
- Provide a signed/controlled EX5 delivery process and EA-side periodic revalidation with offline grace. When a license expires/revokes, block new entries only; do not blindly close existing positions.
- Test MT5 WebRequest from the target broker terminal and verify login/server strings exactly as MT5 reports them.
- Configure backups, monitoring, logging, incident response, database migrations and restore tests.

## API outline
- `POST /api/accounts` — customer submits login, broker and exact server.
- `GET /api/accounts` — customer's account and current license summary.
- `POST /api/admin/accounts/review` — admin approves/rejects IB status.
- `POST /api/orders` — customer creates $10 order for an approved account and network.
- `POST /api/orders/submit-txid` — customer submits TXID.
- `POST /api/admin/orders/review` — admin approves/rejects payment; approval issues a 30-day license token.
- `POST /api/license/validate` — EA validates token + login + server + XAUUSD.
- `GET/POST /api/tickets` — support ticket list/create.
- `POST /api/admin/tickets/reply` — admin responds to ticket.

## MQL5 request
Allow `https://YOUR-DOMAIN` under MT5 > Tools > Options > Expert Advisors > Allow WebRequest for listed URL. Send JSON to `/api/license/validate` with `token`, `login`, `server`, `symbol`. The server returns `valid:true/false`. Fail closed for new entries if invalid; preserve management of existing positions. Do not hardcode database credentials or admin secrets in EA source.
