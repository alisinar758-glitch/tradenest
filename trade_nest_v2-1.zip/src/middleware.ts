import { NextRequest, NextResponse } from "next/server";

const SAFE = new Set(["GET", "HEAD", "OPTIONS"]);

export function middleware(req: NextRequest) {
  const { pathname } = req.nextUrl;

  // CSRF protection: state-changing API calls must come from our own site.
  // The EA license endpoint is called by MetaTrader (no browser Origin) and uses a secret token instead.
  if (pathname.startsWith("/api/") && !SAFE.has(req.method) && pathname !== "/api/license/validate") {
    const origin = req.headers.get("origin");
    const host = req.headers.get("x-forwarded-host") || req.headers.get("host");
    let good = false;
    if (origin) {
      try { good = new URL(origin).host === host; } catch { good = false; }
    } else {
      good = req.headers.get("sec-fetch-site") === "same-origin";
    }
    if (!good) return NextResponse.json({ error: "Forbidden origin" }, { status: 403 });
  }

  const dev = process.env.NODE_ENV !== "production";
  const res = NextResponse.next();
  res.headers.set(
    "Content-Security-Policy",
    [
      "default-src 'self'",
      `script-src 'self' 'unsafe-inline'${dev ? " 'unsafe-eval'" : ""}`,
      "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com",
      "font-src 'self' https://fonts.gstatic.com",
      "img-src 'self' data:",
      "connect-src 'self'",
      "frame-ancestors 'none'",
      "base-uri 'self'",
      "form-action 'self'",
    ].join("; ")
  );
  res.headers.set("X-Frame-Options", "DENY");
  res.headers.set("X-Content-Type-Options", "nosniff");
  res.headers.set("Referrer-Policy", "strict-origin-when-cross-origin");
  res.headers.set("Permissions-Policy", "camera=(), microphone=(), geolocation=()");
  if (!dev) res.headers.set("Strict-Transport-Security", "max-age=63072000; includeSubDomains");
  return res;
}

export const config = { matcher: ["/((?!_next/static|_next/image|favicon.ico).*)"] };
