import Link from "next/link";

export default function LegalPage({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <main className="shell legal">
      <header className="top">
        <Link className="brand" href="/">TRADE<span>NEST</span></Link>
        <Link href="/login">Login</Link>
      </header>
      <h1>{title}</h1>
      <p className="small">Last updated: November 2026</p>
      {children}
    </main>
  );
}
