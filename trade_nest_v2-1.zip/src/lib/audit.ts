import { db } from "./db";
import { clientIp } from "./ratelimit";

export async function audit(req: Request | null, actorId: string | null, action: string, targetType?: string, targetId?: string, detail?: string) {
  try {
    await db.auditLog.create({
      data: { actorId, action, targetType, targetId, detail: detail?.slice(0, 500), ip: req ? clientIp(req) : null },
    });
  } catch (e) {
    console.error("audit failed", e);
  }
}
