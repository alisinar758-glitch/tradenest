import { createHash, randomBytes, createCipheriv, createDecipheriv } from "crypto";

export const hashToken = (s: string) => createHash("sha256").update(s).digest("hex");
export const newLicenseToken = () => "TN-" + randomBytes(24).toString("hex").toUpperCase();

const key = () => createHash("sha256").update("tn-secret-box:" + (process.env.AUTH_SECRET || "")).digest();

export function encryptText(text: string): string {
  const iv = randomBytes(12);
  const c = createCipheriv("aes-256-gcm", key(), iv);
  const enc = Buffer.concat([c.update(text, "utf8"), c.final()]);
  return [iv, c.getAuthTag(), enc].map((b) => b.toString("base64")).join(".");
}

export function decryptText(payload: string): string {
  const [iv, tag, enc] = payload.split(".").map((x) => Buffer.from(x, "base64"));
  const d = createDecipheriv("aes-256-gcm", key(), iv);
  d.setAuthTag(tag);
  return Buffer.concat([d.update(enc), d.final()]).toString("utf8");
}
