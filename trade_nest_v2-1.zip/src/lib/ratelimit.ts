import { NextResponse } from "next/server";

// In-memory limiter: correct for a single server instance (the default Docker setup).
// If you later run several instances, move this to Redis.
type Bucket = { count: number; reset: number };
const store = new Map<string, Bucket>();

export function clientIp(req: Request): string {
  const fwd = req.headers.get("x-forwarded-for");
  return (fwd ? fwd.split(",")[0].trim() : req.headers.get("x-real-ip")) || "unknown";
}

function hit(key: string, max: number, windowMs: number) {
  const now = Date.now();
  if (store.size > 20000) for (const [k, v] of store) if (v.reset < now) store.delete(k);
  const b = store.get(key);
  if (!b || b.reset < now) {
    store.set(key, { count: 1, reset: now + windowMs });
    return { ok: true, retryAfter: 0 };
  }
  b.count++;
  if (b.count > max) return { ok: false, retryAfter: Math.ceil((b.reset - now) / 1000) };
  return { ok: true, retryAfter: 0 };
}

/** Returns a 429 response when the limit is exceeded, otherwise null. */
export function limit(req: Request, name: string, max: number, windowSec: number, extraKey = ""): NextResponse | null {
  const r = hit(`${name}:${clientIp(req)}:${extraKey}`, max, windowSec * 1000);
  if (r.ok) return null;
  return NextResponse.json(
    { error: "Too many requests. Please try again later." },
    { status: 429, headers: { "Retry-After": String(r.retryAfter) } }
  );
}
