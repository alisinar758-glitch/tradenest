export const wallets = { BEP20: process.env.USDT_BEP20_WALLET || "", TRC20: process.env.USDT_TRC20_WALLET || "" };
export const telegramSupport = process.env.NEXT_PUBLIC_TELEGRAM_SUPPORT || "@justmoney2";
export const siteUrl = () => (process.env.SITE_URL || process.env.NEXT_PUBLIC_SITE_URL || "http://localhost:3000").replace(/\/+$/, "");
export const requireEmailVerification = () => process.env.REQUIRE_EMAIL_VERIFICATION !== "false";
export const requireAdmin2fa = () => process.env.REQUIRE_ADMIN_2FA !== "false";
export const RENEW_WINDOW_DAYS = 7;
