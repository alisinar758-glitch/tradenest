import { getSession } from "./session";
import { requireAdmin2fa } from "./config";

/** Admin session. In production an admin must have 2FA enabled (except on the 2FA setup page). */
export async function getAdmin(opts: { allowSetup?: boolean } = {}) {
  const s = await getSession();
  if (!s || s.role !== "ADMIN") return null;
  if (!opts.allowSetup && requireAdmin2fa() && !s.totpEnabled) return null;
  return s;
}
