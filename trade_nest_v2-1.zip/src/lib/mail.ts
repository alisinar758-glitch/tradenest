export async function sendMail(to: string, subject: string, html: string): Promise<boolean> {
  const key = process.env.RESEND_API_KEY;
  const from = process.env.MAIL_FROM;
  if (!key || !from) {
    if (process.env.NODE_ENV !== "production") {
      console.log(`[mail not configured] to=${to}\nsubject=${subject}\n${html.replace(/<[^>]+>/g, " ")}\n`);
    } else {
      console.warn(`[mail not configured] could not send "${subject}" to ${to}`);
    }
    return false;
  }
  try {
    const r = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: { Authorization: `Bearer ${key}`, "Content-Type": "application/json" },
      body: JSON.stringify({ from, to: [to], subject, html }),
    });
    return r.ok;
  } catch {
    return false;
  }
}

/** Fire-and-forget notification: never blocks or breaks the main action. */
export function notify(to: string, subject: string, html: string) {
  void sendMail(to, subject, html).catch(() => {});
}
