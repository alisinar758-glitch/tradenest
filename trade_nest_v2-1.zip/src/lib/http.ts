import { NextResponse } from "next/server";

export async function readJson(req: Request, max = 20000): Promise<any> {
  const text = await req.text();
  if (text.length > max) throw new Error("too_large");
  return JSON.parse(text);
}
export const fail = (error: string, status = 400, extra: Record<string, unknown> = {}) =>
  NextResponse.json({ error, ...extra }, { status });
export const ok = (data: Record<string, unknown> = {}) => NextResponse.json({ ok: true, ...data });
export const isUniqueError = (e: any) => e?.code === "P2002";
