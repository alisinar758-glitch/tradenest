import { SignJWT, jwtVerify } from "jose";
import { cookies } from "next/headers";
import { db } from "./db";
import { requireEmailVerification } from "./config";

export type Session = {
  userId: string;
  email: string;
  role: "CUSTOMER" | "ADMIN";
  verified: boolean;
  totpEnabled: boolean;
};

function key() {
  const s = process.env.AUTH_SECRET || "";
  if (s.length < 32) throw new Error("AUTH_SECRET must be 32+ characters");
  return new TextEncoder().encode(s);
}

export async function createSession(u: { id: string; tokenVersion: number }) {
  const token = await new SignJWT({ uid: u.id, v: u.tokenVersion })
    .setProtectedHeader({ alg: "HS256" })
    .setIssuedAt()
    .setExpirationTime("7d")
    .sign(key());
  (await cookies()).set("tn_session", token, {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "lax",
    path: "/",
    maxAge: 60 * 60 * 24 * 7,
  });
}

export async function getSession(): Promise<Session | null> {
  const token = (await cookies()).get("tn_session")?.value;
  if (!token) return null;
  try {
    const { payload } = await jwtVerify(token, key(), { algorithms: ["HS256"] });
    const u = await db.user.findUnique({ where: { id: String(payload.uid) } });
    // Role, verification state and password-change/logout-everywhere are always read from the database.
    if (!u || u.tokenVersion !== payload.v) return null;
    return {
      userId: u.id,
      email: u.email,
      role: u.role,
      verified: !!u.emailVerifiedAt || !requireEmailVerification(),
      totpEnabled: u.totpEnabled,
    };
  } catch {
    return null;
  }
}
