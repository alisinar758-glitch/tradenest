import { randomBytes } from "crypto";
import { db } from "./db";
import { hashToken } from "./crypto";
import { siteUrl } from "./config";
import { sendMail } from "./mail";

type TokenType = "VERIFY" | "RESET";

export async function issueEmailToken(userId: string, type: TokenType) {
  const raw = randomBytes(32).toString("hex");
  await db.emailToken.deleteMany({ where: { userId, type, usedAt: null } });
  await db.emailToken.create({
    data: {
      userId,
      type,
      tokenHash: hashToken(raw),
      expiresAt: new Date(Date.now() + (type === "RESET" ? 60 * 60 * 1000 : 24 * 60 * 60 * 1000)),
    },
  });
  return raw;
}

/** Returns the userId if the token is valid, and marks it used. */
export async function consumeEmailToken(raw: string, type: TokenType): Promise<string | null> {
  const t = await db.emailToken.findUnique({ where: { tokenHash: hashToken(raw) } });
  if (!t || t.type !== type || t.usedAt || t.expiresAt < new Date()) return null;
  const r = await db.emailToken.updateMany({ where: { id: t.id, usedAt: null }, data: { usedAt: new Date() } });
  return r.count === 1 ? t.userId : null;
}

export async function sendVerification(userId: string, email: string) {
  const token = await issueEmailToken(userId, "VERIFY");
  const link = `${siteUrl()}/verify?token=${token}`;
  return sendMail(email, "Verify your Trade Nest email", `<p>Welcome to Trade Nest.</p><p>Confirm your email address:</p><p><a href="${link}">${link}</a></p><p>This link expires in 24 hours.</p>`);
}

export async function sendReset(userId: string, email: string) {
  const token = await issueEmailToken(userId, "RESET");
  const link = `${siteUrl()}/reset?token=${token}`;
  return sendMail(email, "Reset your Trade Nest password", `<p>We received a password reset request.</p><p><a href="${link}">${link}</a></p><p>This link expires in 1 hour. If you did not ask for it, ignore this email.</p>`);
}
