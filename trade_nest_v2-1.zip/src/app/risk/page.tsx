import LegalPage from "@/components/LegalPage";

export default function Risk() {
  return (
    <LegalPage title="Risk Disclosure">
      <p>Trading gold (XAUUSD) with leverage is highly speculative and you can lose some or all of your capital. Automated strategies, including those using grids, martingale or averaging techniques, can produce large drawdowns during strong one-directional markets, spread widening, news events or gaps.</p>
      <ul>
        <li>Past performance and backtests do not guarantee future results.</li>
        <li>Only trade with money you can afford to lose. Start on a demo account first.</li>
        <li>Slippage, broker execution, latency, internet or VPS failures and platform outages can cause losses.</li>
        <li>Trade Nest does not guarantee profits, does not give personal investment advice and is not a broker or fund manager.</li>
        <li>You alone are responsible for your risk settings, lot sizes and the funds in your account.</li>
      </ul>
    </LegalPage>
  );
}
