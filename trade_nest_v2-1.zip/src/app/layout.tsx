import "./globals.css";
import Link from "next/link";
import { telegramSupport } from "@/lib/config";

export const metadata = { title: "Trade Nest | Gold EA", description: "Licensed XAUUSD Expert Advisor subscriptions" };

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>
        {children}
        <footer className="shell">
          <nav className="legalnav">
            <Link href="/terms">Terms</Link>
            <Link href="/privacy">Privacy</Link>
            <Link href="/risk">Risk disclosure</Link>
            <Link href="/refund">Refund policy</Link>
          </nav>
          <p>Trade Nest · Gold EA · XAUUSD only · Support: {telegramSupport}</p>
        </footer>
      </body>
    </html>
  );
}
