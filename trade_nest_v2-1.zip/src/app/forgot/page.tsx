"use client";
import { useState } from "react";
import Link from "next/link";

export default function Forgot() {
  const [email, setEmail] = useState("");
  const [msg, setMsg] = useState("");
  const [busy, setBusy] = useState(false);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    const r = await fetch("/api/auth/forgot", {
      method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ email }),
    });
    const d = await r.json();
    setMsg(d.message || d.error || "");
    setBusy(false);
  }

  return (
    <main className="shell">
      <Link className="brand" href="/">TRADE<span>NEST</span></Link>
      <section className="panel" style={{ maxWidth: 480, margin: "60px auto" }}>
        <h1>Reset password</h1>
        <form className="formgrid" onSubmit={submit}>
          <input type="email" required placeholder="Your account email" value={email} onChange={(e) => setEmail(e.target.value)} />
          <button disabled={busy}>Send reset link</button>
        </form>
        {msg && <div className="notice">{msg}</div>}
        <p className="muted"><Link href="/login">Back to login</Link></p>
      </section>
    </main>
  );
}
