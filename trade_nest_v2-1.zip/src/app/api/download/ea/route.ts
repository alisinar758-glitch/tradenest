import { readFile } from "fs/promises";
import path from "path";
import { db } from "@/lib/db";
import { getSession } from "@/lib/session";
import { fail } from "@/lib/http";
import { limit } from "@/lib/ratelimit";
import { audit } from "@/lib/audit";

// The EX5 lives outside /public. Only customers with an active license can download it.
export async function GET(req: Request) {
  const s = await getSession();
  if (!s) return fail("Please log in", 401);
  const rl = limit(req, "download", 10, 3600, s.userId);
  if (rl) return rl;
  const lic = await db.license.findFirst({
    where: { userId: s.userId, status: "ACTIVE", expiresAt: { gt: new Date() }, mt5Account: { status: "APPROVED" } },
  });
  if (!lic) return fail("An active subscription is required to download the EA.", 403);
  const file = process.env.EA_FILE_PATH;
  if (!file) return fail("The EA file is not available yet. Please contact support.", 503);
  try {
    const data = await readFile(path.resolve(file));
    await audit(req, s.userId, "EA_DOWNLOAD");
    return new Response(new Uint8Array(data), {
      headers: {
        "Content-Type": "application/octet-stream",
        "Content-Disposition": 'attachment; filename="TradeNestGoldEA.ex5"',
        "Cache-Control": "no-store",
      },
    });
  } catch {
    return fail("The EA file is not available yet. Please contact support.", 503);
  }
}
