import { z } from "zod";
import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getSession } from "@/lib/session";
import { wallets, RENEW_WINDOW_DAYS } from "@/lib/config";
import { readJson, fail } from "@/lib/http";
import { limit } from "@/lib/ratelimit";

export async function POST(req: Request) {
  const s = await getSession();
  if (!s) return fail("Log in first", 401);
  if (!s.verified) return fail("Please verify your email first.", 403);
  const rl = limit(req, "order", 20, 3600, s.userId);
  if (rl) return rl;
  let b: { network: "BEP20" | "TRC20"; mt5AccountId: string };
  try {
    b = z.object({ network: z.enum(["BEP20", "TRC20"]), mt5AccountId: z.string().min(1) }).parse(await readJson(req));
  } catch {
    return fail("Invalid request");
  }

  const account = await db.mt5Account.findFirst({ where: { id: b.mt5AccountId, userId: s.userId, status: "APPROVED" } });
  if (!account) return fail("This MT5 account is not IB-approved yet", 403);

  const product = await db.product.findUnique({ where: { slug: "gold-ea" } });
  if (!product || !product.active) return fail("Product unavailable", 404);

  // Renewal is allowed when the subscription is expired or expires within the renewal window.
  const active = await db.license.findFirst({
    where: { mt5AccountId: account.id, status: "ACTIVE", expiresAt: { gt: new Date() } },
    orderBy: { expiresAt: "desc" },
  });
  if (active && active.expiresAt.getTime() - Date.now() > RENEW_WINDOW_DAYS * 86400000) {
    return fail(`This account is active until ${active.expiresAt.toISOString().slice(0, 10)}. You can renew during the last ${RENEW_WINDOW_DAYS} days.`, 409, { expiresAt: active.expiresAt });
  }

  const wallet = wallets[b.network];
  if (!wallet) return fail("Payment wallet is not configured", 503);

  const open = await db.order.findFirst({ where: { mt5AccountId: account.id, status: "PENDING_PAYMENT" } });
  if (open?.txid) return fail("Your previous payment is still waiting for review.", 409);
  const order = open
    ? await db.order.update({ where: { id: open.id }, data: { network: b.network, walletAddress: wallet } })
    : await db.order.create({
        data: {
          userId: s.userId, productId: product.id, mt5AccountId: account.id,
          amountUsd: product.priceUsd, network: b.network, walletAddress: wallet,
        },
      });
  return NextResponse.json({
    orderId: order.id, amountUsd: product.priceUsd.toString(), network: order.network,
    walletAddress: order.walletAddress, mt5Login: account.login,
  });
}
