import { z } from "zod";
import { db } from "@/lib/db";
import { getSession } from "@/lib/session";
import { readJson, fail, ok, isUniqueError } from "@/lib/http";
import { limit } from "@/lib/ratelimit";

export async function POST(req: Request) {
  const s = await getSession();
  if (!s) return fail("Unauthorized", 401);
  const rl = limit(req, "txid", 20, 3600, s.userId);
  if (rl) return rl;
  let b: { orderId: string; txid: string };
  try {
    b = z.object({ orderId: z.string().min(1), txid: z.string().trim().min(20).max(160) }).parse(await readJson(req));
  } catch {
    return fail("Invalid TXID details");
  }
  const o = await db.order.findFirst({ where: { id: b.orderId, userId: s.userId, status: "PENDING_PAYMENT", txid: null } });
  if (!o) return fail("Order not found or TXID already submitted", 404);

  const txid = b.txid.trim().toLowerCase();
  const valid = o.network === "TRC20" ? /^[0-9a-f]{64}$/.test(txid) : /^0x[0-9a-f]{64}$/.test(txid);
  if (!valid) {
    return fail(o.network === "TRC20"
      ? "A TRC20 TXID is 64 hexadecimal characters."
      : "A BEP20 TXID starts with 0x followed by 64 hexadecimal characters.");
  }
  try {
    await db.order.update({ where: { id: o.id }, data: { txid } });
    return ok({ message: "TXID submitted for manual review" });
  } catch (e) {
    if (isUniqueError(e)) return fail("This TXID has already been submitted", 409);
    return fail("Could not save the TXID", 500);
  }
}
