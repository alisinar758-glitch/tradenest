import { z } from "zod";
import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getSession } from "@/lib/session";
import { readJson, fail, ok, isUniqueError } from "@/lib/http";
import { limit } from "@/lib/ratelimit";

const schema = z.object({
  login: z.string().trim().regex(/^\d{3,15}$/, "MT5 login must contain digits only"),
  broker: z.string().trim().min(2).max(100),
  server: z.string().trim().min(2).max(120),
});

export async function GET() {
  const s = await getSession();
  if (!s) return fail("Unauthorized", 401);
  const rows = await db.mt5Account.findMany({
    where: { userId: s.userId },
    include: { licenses: { orderBy: { createdAt: "desc" }, take: 1 } },
    orderBy: { createdAt: "desc" },
  });
  return NextResponse.json(
    rows.map((a) => ({
      id: a.id, login: a.login, broker: a.broker, server: a.server, status: a.status, adminNote: a.adminNote,
      expiresAt: a.licenses[0]?.expiresAt || null, licenseStatus: a.licenses[0]?.status || null,
    }))
  );
}

export async function POST(req: Request) {
  const s = await getSession();
  if (!s) return fail("Unauthorized", 401);
  if (!s.verified) return fail("Please verify your email first.", 403);
  const rl = limit(req, "account-add", 20, 3600, s.userId);
  if (rl) return rl;
  let b: z.infer<typeof schema>;
  try {
    b = schema.parse(await readJson(req));
  } catch (e) {
    return fail(e instanceof z.ZodError ? e.issues[0].message : "Please check the account details");
  }
  if ((await db.mt5Account.count({ where: { userId: s.userId } })) >= 20) return fail("Account limit reached. Contact support.");
  try {
    const a = await db.mt5Account.create({ data: { ...b, userId: s.userId } });
    return ok({ accountId: a.id, message: "Submitted for manual IB verification" });
  } catch (e) {
    if (isUniqueError(e)) {
      return fail("This MT5 account (login + server) is already registered. If it is yours, open a support ticket so we can resolve it.", 409);
    }
    return fail("Could not save the account", 500);
  }
}

/** Customers may remove their own PENDING/REJECTED accounts that have no payments. */
export async function DELETE(req: Request) {
  const s = await getSession();
  if (!s) return fail("Unauthorized", 401);
  const id = new URL(req.url).searchParams.get("id");
  if (!id) return fail("Missing id");
  const a = await db.mt5Account.findFirst({
    where: { id, userId: s.userId },
    include: { _count: { select: { orders: true, licenses: true } } },
  });
  if (!a) return fail("Account not found", 404);
  if (a.status === "APPROVED" || a._count.orders > 0 || a._count.licenses > 0) {
    return fail("Only pending or rejected accounts without payments can be removed. Contact support.", 409);
  }
  await db.mt5Account.delete({ where: { id: a.id } });
  return ok();
}
