import { z } from "zod";
import { db } from "@/lib/db";
import { getAdmin } from "@/lib/admin";
import { readJson, fail, ok } from "@/lib/http";
import { audit } from "@/lib/audit";
import { notify } from "@/lib/mail";

export async function POST(req: Request) {
  const s = await getAdmin();
  if (!s) return fail("Forbidden", 403);
  try {
    const b = z.object({ ticketId: z.string(), reply: z.string().trim().min(2).max(3000), status: z.enum(["IN_PROGRESS", "CLOSED"]) }).parse(await readJson(req, 8000));
    const t = await db.ticket.update({ where: { id: b.ticketId }, data: { adminReply: b.reply, status: b.status }, include: { user: true } });
    await audit(req, s.userId, "TICKET_REPLY", "Ticket", t.id);
    notify(t.user.email, `Trade Nest support: ${t.subject}`, `<p>${b.reply.replace(/</g, "&lt;").replace(/\n/g, "<br>")}</p>`);
    return ok();
  } catch {
    return fail("Reply failed");
  }
}
