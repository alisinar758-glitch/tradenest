import { z } from "zod";
import { db } from "@/lib/db";
import { getAdmin } from "@/lib/admin";
import { newLicenseToken, hashToken } from "@/lib/crypto";
import { readJson, fail, ok } from "@/lib/http";
import { audit } from "@/lib/audit";
import { notify } from "@/lib/mail";

export async function POST(req: Request) {
  const s = await getAdmin();
  if (!s) return fail("Forbidden", 403);
  let b: { licenseId: string; action: "EXTEND_30_DAYS" | "REVOKE" | "ROTATE_TOKEN" };
  try {
    b = z.object({ licenseId: z.string(), action: z.enum(["EXTEND_30_DAYS", "REVOKE", "ROTATE_TOKEN"]) }).parse(await readJson(req));
  } catch {
    return fail("Invalid request");
  }
  const lic = await db.license.findUnique({ where: { id: b.licenseId }, include: { user: true, mt5Account: true } });
  if (!lic) return fail("License not found", 404);

  if (b.action === "REVOKE") {
    await db.license.update({ where: { id: lic.id }, data: { status: "REVOKED", revokedAt: new Date() } });
    await audit(req, s.userId, "LICENSE_REVOKE", "License", lic.id, `account ${lic.mt5Account.login}`);
    return ok();
  }
  if (b.action === "ROTATE_TOKEN") {
    // For customers who lost their token or whose token leaked. The old token stops working immediately.
    const token = newLicenseToken();
    await db.license.update({ where: { id: lic.id }, data: { tokenHash: hashToken(token) } });
    await audit(req, s.userId, "LICENSE_ROTATE", "License", lic.id, `account ${lic.mt5Account.login}`);
    notify(lic.user.email, "Your new Trade Nest license token", `<p>New license token for MT5 account <b>${lic.mt5Account.login}</b> (the old one no longer works):</p><p><code>${token}</code></p>`);
    return ok({ licenseToken: token });
  }
  const base = lic.expiresAt > new Date() ? lic.expiresAt : new Date();
  const expiresAt = new Date(base.getTime() + 30 * 86400000);
  await db.license.update({ where: { id: lic.id }, data: { status: "ACTIVE", revokedAt: null, expiresAt } });
  await audit(req, s.userId, "LICENSE_EXTEND", "License", lic.id, `account ${lic.mt5Account.login}`);
  return ok({ expiresAt });
}
