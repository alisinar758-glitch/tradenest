import { z } from "zod";
import { db } from "@/lib/db";
import { getAdmin } from "@/lib/admin";
import { newLicenseToken, hashToken } from "@/lib/crypto";
import { readJson, fail, ok } from "@/lib/http";
import { audit } from "@/lib/audit";
import { notify } from "@/lib/mail";
import { siteUrl } from "@/lib/config";

type Result = { renewed: boolean; expiresAt: Date; token: string | null };

export async function POST(req: Request) {
  const s = await getAdmin();
  if (!s) return fail("Forbidden", 403);
  let b: { orderId: string; decision: "APPROVE" | "REJECT"; note?: string };
  try {
    b = z.object({ orderId: z.string(), decision: z.enum(["APPROVE", "REJECT"]), note: z.string().max(500).optional() }).parse(await readJson(req));
  } catch {
    return fail("Invalid request");
  }
  const order = await db.order.findUnique({
    where: { id: b.orderId },
    include: { mt5Account: true, user: true, product: true },
  });
  if (!order || order.status !== "PENDING_PAYMENT" || !order.txid) return fail("Order missing TXID or already reviewed", 409);

  if (b.decision === "REJECT") {
    const r = await db.order.updateMany({
      where: { id: order.id, status: "PENDING_PAYMENT" },
      data: { status: "REJECTED", adminNote: b.note || "Payment not verified", reviewedAt: new Date() },
    });
    if (r.count !== 1) return fail("Order already reviewed", 409);
    await audit(req, s.userId, "ORDER_REJECT", "Order", order.id, b.note);
    notify(order.user.email, "Trade Nest payment not verified", `<p>We could not verify your payment for MT5 account ${order.mt5Account.login}.</p><p>${b.note ? "Note: " + b.note.replace(/</g, "&lt;") : ""}</p><p>Please open a support ticket if you believe this is a mistake.</p>`);
    return ok();
  }

  if (order.mt5Account.status !== "APPROVED") return fail("MT5 account is not IB-approved", 409);

  let result: Result;
  try {
    result = await db.$transaction(async (tx): Promise<Result> => {
      const claimed = await tx.order.updateMany({
        where: { id: order.id, status: "PENDING_PAYMENT" },
        data: { status: "PAID", adminNote: b.note || null, reviewedAt: new Date() },
      });
      if (claimed.count !== 1) throw new Error("already_reviewed");
      const ms = order.product.durationDays * 86400000;
      const existing = await tx.license.findFirst({
        where: { mt5AccountId: order.mt5AccountId, status: { in: ["ACTIVE", "EXPIRED"] } },
        orderBy: { expiresAt: "desc" },
      });
      if (existing) {
        // Renewal: same token keeps working; time is added on top of any remaining days.
        const base = existing.expiresAt > new Date() ? existing.expiresAt : new Date();
        const expiresAt = new Date(base.getTime() + ms);
        await tx.license.update({ where: { id: existing.id }, data: { status: "ACTIVE", expiresAt } });
        await tx.order.update({ where: { id: order.id }, data: { appliedLicenseId: existing.id } });
        return { renewed: true, expiresAt, token: null };
      }
      const token = newLicenseToken();
      const expiresAt = new Date(Date.now() + ms);
      const lic = await tx.license.create({
        data: {
          tokenHash: hashToken(token), userId: order.userId, productId: order.productId,
          mt5AccountId: order.mt5AccountId, orderId: order.id, expiresAt,
        },
      });
      await tx.order.update({ where: { id: order.id }, data: { appliedLicenseId: lic.id } });
      return { renewed: false, expiresAt, token };
    });
  } catch (e: any) {
    if (e?.message === "already_reviewed") return fail("Order already reviewed", 409);
    return fail("Approval failed", 500);
  }

  await audit(req, s.userId, result.renewed ? "ORDER_APPROVE_RENEW" : "ORDER_APPROVE_NEW", "Order", order.id, `account ${order.mt5Account.login}`);
  const until = result.expiresAt.toISOString().slice(0, 10);
  if (result.token) {
    notify(order.user.email, "Your Trade Nest license", `<p>Payment confirmed for MT5 account <b>${order.mt5Account.login}</b>.</p><p>License token (keep it private):</p><p><code>${result.token}</code></p><p>Valid until ${until}. Download the EA from your dashboard: ${siteUrl()}/dashboard</p>`);
  } else {
    notify(order.user.email, "Trade Nest subscription renewed", `<p>Payment confirmed for MT5 account <b>${order.mt5Account.login}</b>. Your existing license token keeps working and is now valid until ${until}.</p>`);
  }
  return ok({ licenseToken: result.token, renewed: result.renewed, expiresAt: result.expiresAt });
}
