import { z } from "zod";
import { db } from "@/lib/db";
import { getAdmin } from "@/lib/admin";
import { readJson, fail, ok } from "@/lib/http";
import { audit } from "@/lib/audit";
import { notify } from "@/lib/mail";

export async function POST(req: Request) {
  const s = await getAdmin();
  if (!s) return fail("Forbidden", 403);
  let b: { accountId: string; decision: "APPROVE" | "REJECT" | "DELETE"; note?: string };
  try {
    b = z.object({ accountId: z.string(), decision: z.enum(["APPROVE", "REJECT", "DELETE"]), note: z.string().max(500).optional() }).parse(await readJson(req));
  } catch {
    return fail("Invalid request");
  }
  const a = await db.mt5Account.findUnique({
    where: { id: b.accountId },
    include: { user: true, _count: { select: { orders: true, licenses: true } } },
  });
  if (!a) return fail("Account not found", 404);

  if (b.decision === "DELETE") {
    // Frees the login+server pair, e.g. when someone registered an account that is not theirs.
    if (a._count.orders > 0 || a._count.licenses > 0) return fail("Account has orders or licenses. Reject it instead.", 409);
    await db.mt5Account.delete({ where: { id: a.id } });
    await audit(req, s.userId, "ACCOUNT_DELETE", "Mt5Account", a.id, `${a.login} ${a.server} ${b.note || ""}`);
    return ok();
  }

  const approve = b.decision === "APPROVE";
  await db.mt5Account.update({
    where: { id: a.id },
    data: { status: approve ? "APPROVED" : "REJECTED", adminNote: b.note || null, verifiedAt: approve ? new Date() : null },
  });
  await audit(req, s.userId, approve ? "ACCOUNT_APPROVE" : "ACCOUNT_REJECT", "Mt5Account", a.id, `${a.login} ${b.note || ""}`);
  notify(
    a.user.email,
    approve ? "MT5 account approved" : "MT5 account not approved",
    approve
      ? `<p>Your MT5 account <b>${a.login}</b> is IB-approved. You can now subscribe from your dashboard.</p>`
      : `<p>Your MT5 account <b>${a.login}</b> could not be approved.</p><p>${b.note ? "Note: " + b.note.replace(/</g, "&lt;") : ""}</p>`
  );
  return ok();
}
