import { z } from "zod";
import { db } from "@/lib/db";
import { getAdmin } from "@/lib/admin";
import { encryptText, decryptText } from "@/lib/crypto";
import { newTotpSecret, verifyTotp, otpauthUri } from "@/lib/totp";
import { readJson, fail, ok } from "@/lib/http";
import { limit } from "@/lib/ratelimit";
import { audit } from "@/lib/audit";

export async function POST(req: Request) {
  const s = await getAdmin({ allowSetup: true });
  if (!s) return fail("Forbidden", 403);
  const rl = limit(req, "admin2fa", 10, 600, s.userId);
  if (rl) return rl;
  let b: { action: "setup" | "enable"; code?: string };
  try {
    b = z.object({ action: z.enum(["setup", "enable"]), code: z.string().optional() }).parse(await readJson(req));
  } catch {
    return fail("Invalid request");
  }
  const u = await db.user.findUnique({ where: { id: s.userId } });
  if (!u) return fail("Not found", 404);

  if (b.action === "setup") {
    if (u.totpEnabled) return fail("2FA is already enabled. To reset it, clear it in the database.", 409);
    const secret = newTotpSecret();
    await db.user.update({ where: { id: u.id }, data: { totpSecret: encryptText(secret) } });
    return ok({ secret, uri: otpauthUri(u.email, secret) });
  }
  if (!u.totpSecret) return fail("Run setup first", 409);
  if (!b.code || !verifyTotp(decryptText(u.totpSecret), b.code.trim())) return fail("Invalid code", 400);
  await db.user.update({ where: { id: u.id }, data: { totpEnabled: true } });
  await audit(req, u.id, "ADMIN_2FA_ENABLED");
  return ok();
}
