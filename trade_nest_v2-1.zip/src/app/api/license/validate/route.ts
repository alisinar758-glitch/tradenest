import { NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { hashToken } from "@/lib/crypto";
import { limit } from "@/lib/ratelimit";
import { readJson } from "@/lib/http";

const schema = z.object({
  token: z.string().min(20).max(120),
  login: z.string().min(1).max(40),
  server: z.string().min(1).max(120),
  symbol: z.string().max(40).optional(),
});

const reply = (valid: boolean, reason: string, extra: Record<string, unknown> = {}, status = 200) =>
  NextResponse.json({ valid, reason, serverTime: new Date().toISOString(), ...extra }, { status, headers: { "Cache-Control": "no-store" } });

export async function POST(req: Request) {
  const rl = limit(req, "validate", 300, 600);
  if (rl) return rl;
  let b: z.infer<typeof schema>;
  try {
    b = schema.parse(await readJson(req, 4000));
  } catch {
    return reply(false, "BAD_REQUEST", {}, 400);
  }
  const lic = await db.license.findUnique({
    where: { tokenHash: hashToken(b.token.trim()) },
    include: { product: true, mt5Account: true },
  });
  if (!lic) return reply(false, "NOT_FOUND");
  if (lic.status === "REVOKED") return reply(false, "REVOKED");
  if (lic.status !== "ACTIVE" || lic.expiresAt <= new Date()) return reply(false, "EXPIRED");
  if (!lic.product.active) return reply(false, "PRODUCT_DISABLED");
  if (lic.mt5Account.status !== "APPROVED") return reply(false, "IB_NOT_APPROVED");
  if (lic.mt5Account.login !== b.login.trim() || lic.mt5Account.server.toLowerCase() !== b.server.trim().toLowerCase()) {
    return reply(false, "ACCOUNT_MISMATCH");
  }
  // Brokers add suffixes (XAUUSD.c, XAUUSDm, GOLD...). Match on the product symbol prefix.
  if (b.symbol && !b.symbol.toUpperCase().startsWith(lic.product.symbol.toUpperCase())) {
    return reply(false, "SYMBOL_MISMATCH");
  }
  await db.license.update({ where: { id: lic.id }, data: { lastValidatedAt: new Date() } });
  return reply(true, "ACTIVE", { product: lic.product.slug, expiresAt: lic.expiresAt });
}
