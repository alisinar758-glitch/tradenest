import { z } from "zod";
import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getSession } from "@/lib/session";
import { readJson, fail, ok } from "@/lib/http";
import { limit } from "@/lib/ratelimit";

export async function GET() {
  const s = await getSession();
  if (!s) return fail("Unauthorized", 401);
  const rows = await db.ticket.findMany({
    where: s.role === "ADMIN" ? {} : { userId: s.userId },
    include: { user: { select: { email: true } } },
    orderBy: { createdAt: "desc" },
    take: 200,
  });
  return NextResponse.json(rows);
}

export async function POST(req: Request) {
  const s = await getSession();
  if (!s) return fail("Unauthorized", 401);
  const rl = limit(req, "ticket", 10, 3600, s.userId);
  if (rl) return rl;
  try {
    const b = z.object({ subject: z.string().trim().min(4).max(120), message: z.string().trim().min(10).max(3000) }).parse(await readJson(req, 8000));
    const t = await db.ticket.create({ data: { userId: s.userId, ...b } });
    return ok({ ticketId: t.id });
  } catch {
    return fail("Please complete the ticket details");
  }
}
