import { z } from "zod";
import { db } from "@/lib/db";
import { readJson, ok, fail } from "@/lib/http";
import { limit } from "@/lib/ratelimit";
import { sendVerification } from "@/lib/emailTokens";
import { getSession } from "@/lib/session";

export async function POST(req: Request) {
  const rl = limit(req, "resend", 3, 3600);
  if (rl) return rl;
  try {
    const body = await readJson(req);
    const s = await getSession();
    const email = s ? s.email : z.string().email().parse(body.email).trim().toLowerCase();
    const u = await db.user.findUnique({ where: { email } });
    if (u && !u.emailVerifiedAt) await sendVerification(u.id, u.email);
    return ok({ message: "If the account exists and is not verified, a new link was sent." });
  } catch {
    return fail("Invalid request");
  }
}
