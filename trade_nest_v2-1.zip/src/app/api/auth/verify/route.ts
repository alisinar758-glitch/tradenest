import { z } from "zod";
import { db } from "@/lib/db";
import { readJson, fail, ok } from "@/lib/http";
import { limit } from "@/lib/ratelimit";
import { consumeEmailToken } from "@/lib/emailTokens";

export async function POST(req: Request) {
  const rl = limit(req, "verify", 20, 3600);
  if (rl) return rl;
  try {
    const { token } = z.object({ token: z.string().min(20).max(200) }).parse(await readJson(req));
    const userId = await consumeEmailToken(token, "VERIFY");
    if (!userId) return fail("This link is invalid or has expired. Request a new one from the login page.", 400);
    await db.user.update({ where: { id: userId }, data: { emailVerifiedAt: new Date() } });
    return ok();
  } catch {
    return fail("Invalid request");
  }
}
