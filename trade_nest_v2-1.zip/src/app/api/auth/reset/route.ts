import { z } from "zod";
import bcrypt from "bcryptjs";
import { db } from "@/lib/db";
import { readJson, ok, fail } from "@/lib/http";
import { limit } from "@/lib/ratelimit";
import { consumeEmailToken } from "@/lib/emailTokens";

export async function POST(req: Request) {
  const rl = limit(req, "reset", 10, 3600);
  if (rl) return rl;
  try {
    const b = z.object({ token: z.string().min(20).max(200), password: z.string().min(10).max(100) }).parse(await readJson(req));
    const userId = await consumeEmailToken(b.token, "RESET");
    if (!userId) return fail("This reset link is invalid or has expired.", 400);
    const u = await db.user.findUnique({ where: { id: userId } });
    if (!u) return fail("Account not found", 404);
    await db.user.update({
      where: { id: userId },
      data: {
        passwordHash: await bcrypt.hash(b.password, 12),
        tokenVersion: { increment: 1 },
        emailVerifiedAt: u.emailVerifiedAt ?? new Date(),
        failedLogins: 0,
        lockedUntil: null,
      },
    });
    return ok();
  } catch {
    return fail("Use a password of at least 10 characters.");
  }
}
