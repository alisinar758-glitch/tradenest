import { NextResponse } from "next/server";
import { z } from "zod";
import bcrypt from "bcryptjs";
import { db } from "@/lib/db";
import { createSession } from "@/lib/session";
import { readJson, fail } from "@/lib/http";
import { limit } from "@/lib/ratelimit";
import { requireEmailVerification } from "@/lib/config";
import { decryptText } from "@/lib/crypto";
import { verifyTotp } from "@/lib/totp";
import { audit } from "@/lib/audit";

const schema = z.object({
  email: z.string().email(),
  password: z.string().min(1).max(100),
  code: z.string().optional(),
});

let dummyHash: string | null = null;
const dummy = () => (dummyHash ??= bcrypt.hashSync("tradenest-dummy-password", 12));

export async function POST(req: Request) {
  const rl = limit(req, "login", 15, 600);
  if (rl) return rl;
  let b: z.infer<typeof schema>;
  try {
    b = schema.parse(await readJson(req));
  } catch {
    return fail("Enter your email and password");
  }
  const email = b.email.trim().toLowerCase();
  const u = await db.user.findUnique({ where: { email } });
  if (u?.lockedUntil && u.lockedUntil > new Date()) {
    return fail("Too many failed attempts. Please try again in 15 minutes.", 429);
  }

  const passwordOk = await bcrypt.compare(b.password, u?.passwordHash ?? dummy());
  const registerFailure = async () => {
    if (!u) return;
    const failed = u.failedLogins + 1;
    await db.user.update({
      where: { id: u.id },
      data: failed >= 5 ? { failedLogins: 0, lockedUntil: new Date(Date.now() + 15 * 60 * 1000) } : { failedLogins: failed },
    });
  };
  if (!u || !passwordOk) {
    await registerFailure();
    return fail("Invalid email or password", 401);
  }
  if (requireEmailVerification() && !u.emailVerifiedAt) {
    return fail("Please verify your email first. Check your inbox (and spam folder).", 403, { needVerify: true });
  }
  if (u.totpEnabled && u.totpSecret) {
    if (!b.code) return fail("Enter your 6-digit authenticator code", 401, { needTotp: true });
    if (!verifyTotp(decryptText(u.totpSecret), b.code.trim())) {
      await registerFailure();
      return fail("Invalid authenticator code", 401, { needTotp: true });
    }
  }
  await db.user.update({ where: { id: u.id }, data: { failedLogins: 0, lockedUntil: null } });
  await createSession({ id: u.id, tokenVersion: u.tokenVersion });
  if (u.role === "ADMIN") await audit(req, u.id, "ADMIN_LOGIN");
  return NextResponse.json({ ok: true, role: u.role });
}
