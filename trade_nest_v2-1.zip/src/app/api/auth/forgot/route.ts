import { z } from "zod";
import { db } from "@/lib/db";
import { readJson, ok, fail } from "@/lib/http";
import { limit } from "@/lib/ratelimit";
import { sendReset } from "@/lib/emailTokens";

export async function POST(req: Request) {
  const rl = limit(req, "forgot", 5, 3600);
  if (rl) return rl;
  try {
    const { email } = z.object({ email: z.string().email() }).parse(await readJson(req));
    const clean = email.trim().toLowerCase();
    const rl2 = limit(req, "forgot-email", 3, 3600, clean);
    if (rl2) return rl2;
    const u = await db.user.findUnique({ where: { email: clean } });
    if (u) await sendReset(u.id, u.email);
    return ok({ message: "If that email is registered, a reset link has been sent." });
  } catch {
    return fail("Enter a valid email");
  }
}
