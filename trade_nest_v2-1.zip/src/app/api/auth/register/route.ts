import { NextResponse } from "next/server";
import { z } from "zod";
import bcrypt from "bcryptjs";
import { db } from "@/lib/db";
import { readJson, fail, isUniqueError } from "@/lib/http";
import { limit } from "@/lib/ratelimit";
import { requireEmailVerification } from "@/lib/config";
import { sendVerification } from "@/lib/emailTokens";

const schema = z.object({
  email: z.string().email().max(190),
  password: z.string().min(10).max(100),
  acceptTerms: z.literal(true),
});

export async function POST(req: Request) {
  const rl = limit(req, "register", 5, 3600);
  if (rl) return rl;
  let b: z.infer<typeof schema>;
  try {
    b = schema.parse(await readJson(req));
  } catch {
    return fail("Enter a valid email, a password of at least 10 characters, and accept the terms.");
  }
  const email = b.email.trim().toLowerCase();
  try {
    const user = await db.user.create({
      data: { email, passwordHash: await bcrypt.hash(b.password, 12), termsAcceptedAt: new Date() },
    });
    const verifyRequired = requireEmailVerification();
    if (verifyRequired) await sendVerification(user.id, email);
    return NextResponse.json({ ok: true, verifyRequired });
  } catch (e) {
    if (isUniqueError(e)) return fail("Email already registered", 409);
    return fail("Registration failed", 500);
  }
}
