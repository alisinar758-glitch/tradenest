"use client";
import { Suspense, useState } from "react";
import Link from "next/link";
import { useSearchParams } from "next/navigation";

function VerifyBox() {
  const token = useSearchParams().get("token") || "";
  const [state, setState] = useState<"idle" | "ok" | "err">("idle");
  const [msg, setMsg] = useState("");

  async function confirm() {
    const r = await fetch("/api/auth/verify", {
      method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ token }),
    });
    const d = await r.json();
    if (r.ok) setState("ok"); else { setState("err"); setMsg(d.error || "Verification failed"); }
  }

  if (state === "ok") return <div className="notice">Email confirmed. <Link href="/login">Log in</Link></div>;
  return (
    <>
      <p className="muted">Press the button to confirm your email address.</p>
      <button onClick={confirm} disabled={!token}>Confirm my email</button>
      {state === "err" && <p>{msg}</p>}
    </>
  );
}

export default function Verify() {
  return (
    <main className="shell">
      <Link className="brand" href="/">TRADE<span>NEST</span></Link>
      <section className="panel" style={{ maxWidth: 480, margin: "60px auto" }}>
        <h1>Confirm email</h1>
        <Suspense fallback={null}><VerifyBox /></Suspense>
      </section>
    </main>
  );
}
