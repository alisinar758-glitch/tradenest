import Link from "next/link";
import { telegramSupport } from "@/lib/config";

export default function Home() {
  return (
    <main className="shell">
      <header className="top">
        <a className="brand" href="/">TRADE<span>NEST</span></a>
        <nav><Link href="/login">Login</Link>　<Link href="/register">Create account</Link></nav>
      </header>
      <section style={{ padding: "70px 0 60px", maxWidth: 760 }}>
        <p style={{ color: "#e4b94f", letterSpacing: 3 }}>AUTOMATED GOLD TRADING</p>
        <h1 style={{ fontSize: 52, lineHeight: 1.08 }}>Trade Gold with <span style={{ color: "#e4b94f" }}>Trade Nest</span></h1>
        <p className="muted" style={{ fontSize: 18, lineHeight: 1.7 }}>
          A licensed Expert Advisor service for XAUUSD on MetaTrader 5. Register your MT5 account, complete IB verification, and activate a monthly subscription.
        </p>
        <div className="actions">
          <Link href="/register"><button>Create your account</button></Link>
          <Link href="/login">Customer login →</Link>
        </div>
      </section>
      <section className="panel">
        <h2>Simple monthly pricing</h2>
        <p><strong style={{ fontSize: 38, color: "#e4b94f" }}>$10</strong> / MT5 account / 30 days</p>
        <p className="muted">Each MT5 account requires separate IB approval and its own subscription. Pay with USDT TRC20 or BEP20.</p>
      </section>
      <section className="panel">
        <h2>How it works</h2>
        <ol>
          <li>Create your Trade Nest account and confirm your email.</li>
          <li>Submit your MT5 login, broker and exact server name.</li>
          <li>We manually confirm that the account is under our IB.</li>
          <li>Pay $10 USDT for that account and submit the TXID.</li>
          <li>After payment verification you receive a license token and can download the EA from your dashboard.</li>
          <li>Renew from the dashboard during the last 7 days of your subscription, or after it ends.</li>
        </ol>
      </section>
      <p className="small">Gold EA is intended for XAUUSD only. Trading involves substantial risk; profits are not guaranteed. Support: {telegramSupport}. Never submit your MT5 trading password or investor password to this website.</p>
    </main>
  );
}
