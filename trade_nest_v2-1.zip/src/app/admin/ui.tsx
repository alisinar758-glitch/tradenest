"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";

type A = { id: string; email: string; login: string; broker: string; server: string; status: string; note: string | null };
type O = { id: string; email: string; login: string; network: string; amount: string; wallet: string; txid: string | null; status: string };
type T = { id: string; email: string; subject: string; message: string; status: string; reply: string | null };
type L = { id: string; email: string; login: string; status: string; expiresAt: string; lastSeen: string | null };
type G = { id: string; at: string; action: string; detail: string; ip: string };

const explorer = (o: O) => (o.network === "TRC20" ? `https://tronscan.org/#/transaction/${o.txid}` : `https://bscscan.com/tx/${o.txid}`);

export default function AdminClient({ accounts, orders, tickets, licenses, logs }: { accounts: A[]; orders: O[]; tickets: T[]; licenses: L[]; logs: G[] }) {
  const router = useRouter();
  const [note, setNote] = useState<Record<string, string>>({});
  const [reply, setReply] = useState<Record<string, string>>({});
  const [msg, setMsg] = useState("");

  async function post(url: string, body: unknown) {
    const r = await fetch(url, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });
    const d = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error(d.error || "Failed");
    return d;
  }
  async function act(fn: () => Promise<string | void>) {
    setMsg("");
    try { const m = await fn(); if (m) setMsg(m); router.refresh(); } catch (e: any) { setMsg(e.message); }
  }
  const logout = async () => { await fetch("/api/auth/logout", { method: "POST" }); window.location.href = "/"; };

  const reviewAccount = (id: string, decision: string) => act(async () => { await post("/api/admin/accounts/review", { accountId: id, decision, note: note[id] || "" }); });
  const reviewOrder = (id: string, decision: string) => act(async () => {
    const d = await post("/api/admin/orders/review", { orderId: id, decision, note: note[id] || "" });
    if (decision === "REJECT") return "Order rejected.";
    return d.licenseToken ? `APPROVED. New license token (also emailed to the customer if email is configured) — copy it now: ${d.licenseToken}` : `APPROVED. Renewal applied, valid until ${new Date(d.expiresAt).toLocaleDateString()}. The customer's existing token keeps working.`;
  });
  const manageLicense = (id: string, action: string) => act(async () => {
    if (action === "REVOKE" && !confirm("Revoke this license?")) return;
    if (action === "ROTATE_TOKEN" && !confirm("Create a new token? The old token stops working immediately.")) return;
    const d = await post("/api/admin/licenses/manage", { licenseId: id, action });
    return d.licenseToken ? `New license token — copy it now: ${d.licenseToken}` : undefined;
  });
  const replyTicket = (id: string, status: string) => act(async () => { await post("/api/admin/tickets/reply", { ticketId: id, reply: reply[id] || "", status }); });

  return (
    <main className="shell">
      <header className="top">
        <a className="brand" href="/">TRADE<span>NEST</span></a>
        <div><a href="/dashboard">Customer view</a> · <button className="link" onClick={logout}>Log out</button></div>
      </header>
      <h1>Admin control panel</h1>
      <p className="muted">Verify IB accounts, confirm blockchain payments, manage subscriptions and support.</p>
      {msg && <div className="notice mono">{msg}</div>}

      <section className="panel">
        <h2>MT5 / IB verification ({accounts.filter((a) => a.status === "PENDING").length} pending)</h2>
        {accounts.map((a) => (
          <article className="adminrow" key={a.id}>
            <b>{a.login}</b> · {a.email}
            <p>{a.broker} / {a.server} · <b>{a.status}</b></p>
            <input placeholder="Admin note (verification source / reason)" value={note[a.id] || ""} onChange={(e) => setNote({ ...note, [a.id]: e.target.value })} />
            <div className="actions">
              <button onClick={() => reviewAccount(a.id, "APPROVE")}>Approve IB</button>
              <button className="danger" onClick={() => reviewAccount(a.id, "REJECT")}>Reject</button>
              <button className="secondary" onClick={() => confirm("Delete this registration? (frees the login+server)") && reviewAccount(a.id, "DELETE")}>Delete</button>
            </div>
          </article>
        ))}
      </section>

      <section className="panel">
        <h2>USDT payment review ({orders.filter((o) => o.status === "PENDING_PAYMENT" && o.txid).length} waiting)</h2>
        <p className="small">Before approval, open the explorer link and verify: token is USDT, correct network, amount of at least the order amount, destination equals the wallet below, status successful with enough confirmations, and the TXID was not used before.</p>
        {orders.map((o) => (
          <article className="adminrow" key={o.id}>
            <b>{o.email}</b> · MT5 {o.login}
            <p>${o.amount} · {o.network} · {o.status}</p>
            <p className="small mono">Wallet: {o.wallet}<br />TXID: {o.txid ? <a href={explorer(o)} target="_blank" rel="noopener noreferrer">{o.txid}</a> : "Not submitted"}<br />Order: {o.id}</p>
            {o.status === "PENDING_PAYMENT" && o.txid && (
              <>
                <input placeholder="Admin note" value={note[o.id] || ""} onChange={(e) => setNote({ ...note, [o.id]: e.target.value })} />
                <div className="actions">
                  <button onClick={() => reviewOrder(o.id, "APPROVE")}>Verified — activate / renew 30 days</button>
                  <button className="danger" onClick={() => reviewOrder(o.id, "REJECT")}>Reject payment</button>
                </div>
              </>
            )}
          </article>
        ))}
      </section>

      <section className="panel">
        <h2>Subscription management</h2>
        {licenses.map((l) => (
          <article className="adminrow" key={l.id}>
            <b>{l.email}</b> · MT5 {l.login}
            <p>{l.status} · Expires {new Date(l.expiresAt).toLocaleString()} · EA last seen {l.lastSeen ? new Date(l.lastSeen).toLocaleString() : "never"}</p>
            <div className="actions">
              <button onClick={() => manageLicense(l.id, "EXTEND_30_DAYS")}>Extend 30 days</button>
              <button className="secondary" onClick={() => manageLicense(l.id, "ROTATE_TOKEN")}>New token</button>
              <button className="danger" onClick={() => manageLicense(l.id, "REVOKE")}>Revoke</button>
            </div>
          </article>
        ))}
      </section>

      <section className="panel">
        <h2>Support tickets</h2>
        {tickets.map((t) => (
          <article className="adminrow" key={t.id}>
            <b>{t.subject}</b> · {t.email} · {t.status}
            <p>{t.message}</p>
            {t.reply && <p className="small">Last reply: {t.reply}</p>}
            <textarea placeholder="Write support reply" value={reply[t.id] || ""} onChange={(e) => setReply({ ...reply, [t.id]: e.target.value })} />
            <div className="actions">
              <button onClick={() => replyTicket(t.id, "CLOSED")}>Reply & close</button>
              <button className="secondary" onClick={() => replyTicket(t.id, "IN_PROGRESS")}>Reply, keep open</button>
            </div>
          </article>
        ))}
      </section>

      <section className="panel">
        <h2>Audit log (last 50)</h2>
        <div className="tablewrap">
          <table>
            <thead><tr><th>Time</th><th>Action</th><th>Detail</th><th>IP</th></tr></thead>
            <tbody>{logs.map((g) => <tr key={g.id}><td>{new Date(g.at).toLocaleString()}</td><td>{g.action}</td><td>{g.detail}</td><td>{g.ip}</td></tr>)}</tbody>
          </table>
        </div>
      </section>
    </main>
  );
}
