import { redirect } from "next/navigation";
import { getSession } from "@/lib/session";
import { requireAdmin2fa } from "@/lib/config";
import { db } from "@/lib/db";
import AdminClient from "./ui";

const pendingFirst = <T,>(arr: T[], isPending: (x: T) => boolean) => [...arr].sort((a, b) => Number(isPending(b)) - Number(isPending(a)));

export default async function Admin() {
  const s = await getSession();
  if (!s) redirect("/login");
  if (s.role !== "ADMIN") redirect("/dashboard");
  if (requireAdmin2fa() && !s.totpEnabled) redirect("/admin/security");

  const [accounts, orders, tickets, licenses, logs] = await Promise.all([
    db.mt5Account.findMany({ include: { user: { select: { email: true } } }, orderBy: { createdAt: "desc" }, take: 300 }),
    db.order.findMany({ include: { user: { select: { email: true } }, mt5Account: true }, orderBy: { createdAt: "desc" }, take: 300 }),
    db.ticket.findMany({ include: { user: { select: { email: true } } }, orderBy: { createdAt: "desc" }, take: 200 }),
    db.license.findMany({ include: { user: { select: { email: true } }, mt5Account: true }, orderBy: { createdAt: "desc" }, take: 300 }),
    db.auditLog.findMany({ orderBy: { createdAt: "desc" }, take: 50 }),
  ]);

  return (
    <AdminClient
      accounts={pendingFirst(accounts, (a) => a.status === "PENDING").map((a) => ({ id: a.id, email: a.user.email, login: a.login, broker: a.broker, server: a.server, status: a.status, note: a.adminNote }))}
      orders={pendingFirst(orders, (o) => o.status === "PENDING_PAYMENT" && !!o.txid).map((o) => ({ id: o.id, email: o.user.email, login: o.mt5Account.login, network: o.network, amount: o.amountUsd.toString(), wallet: o.walletAddress, txid: o.txid, status: o.status }))}
      tickets={pendingFirst(tickets, (t) => t.status !== "CLOSED").map((t) => ({ id: t.id, email: t.user.email, subject: t.subject, message: t.message, status: t.status, reply: t.adminReply }))}
      licenses={licenses.map((l) => ({ id: l.id, email: l.user.email, login: l.mt5Account.login, status: l.status, expiresAt: l.expiresAt.toISOString(), lastSeen: l.lastValidatedAt?.toISOString() || null }))}
      logs={logs.map((l) => ({ id: l.id, at: l.createdAt.toISOString(), action: l.action, detail: l.detail || "", ip: l.ip || "" }))}
    />
  );
}
