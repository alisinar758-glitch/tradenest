"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";

export default function SecurityClient({ enabled }: { enabled: boolean }) {
  const router = useRouter();
  const [secret, setSecret] = useState("");
  const [uri, setUri] = useState("");
  const [code, setCode] = useState("");
  const [msg, setMsg] = useState("");

  async function call(body: unknown) {
    const r = await fetch("/api/admin/2fa", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });
    const d = await r.json();
    if (!r.ok) throw new Error(d.error || "Failed");
    return d;
  }
  async function setup() {
    try { const d = await call({ action: "setup" }); setSecret(d.secret); setUri(d.uri); setMsg(""); } catch (e: any) { setMsg(e.message); }
  }
  async function enable() {
    try { await call({ action: "enable", code }); setMsg("2FA enabled. Use your authenticator code at every admin login."); router.push("/admin"); router.refresh(); } catch (e: any) { setMsg(e.message); }
  }

  return (
    <main className="shell">
      <header className="top"><a className="brand" href="/">TRADE<span>NEST</span></a></header>
      <h1>Admin two-factor authentication</h1>
      {enabled ? (
        <div className="notice">Two-factor authentication is enabled on this admin account.</div>
      ) : (
        <section className="panel">
          <p className="muted">Admin access requires an authenticator app (Google Authenticator, Microsoft Authenticator, Aegis, 1Password...).</p>
          {!secret ? (
            <button onClick={setup}>Generate secret</button>
          ) : (
            <>
              <p>In your authenticator app choose "Enter a setup key", account name <b>Trade Nest</b>, type <b>time-based</b>, and enter this key:</p>
              <p className="mono notice">{secret}</p>
              <p className="small mono">{uri}</p>
              <div className="formgrid">
                <input inputMode="numeric" maxLength={6} placeholder="6-digit code from the app" value={code} onChange={(e) => setCode(e.target.value)} />
                <button onClick={enable}>Verify and enable</button>
              </div>
            </>
          )}
          {msg && <p>{msg}</p>}
        </section>
      )}
    </main>
  );
}
