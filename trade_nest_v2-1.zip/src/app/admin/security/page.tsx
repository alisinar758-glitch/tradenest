import { redirect } from "next/navigation";
import { getSession } from "@/lib/session";
import SecurityClient from "./ui";

export default async function Security() {
  const s = await getSession();
  if (!s) redirect("/login");
  if (s.role !== "ADMIN") redirect("/dashboard");
  return <SecurityClient enabled={s.totpEnabled} />;
}
