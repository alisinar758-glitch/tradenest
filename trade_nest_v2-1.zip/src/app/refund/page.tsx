import LegalPage from "@/components/LegalPage";
import { telegramSupport } from "@/lib/config";

export default function Refund() {
  return (
    <LegalPage title="Refund Policy">
      <ul>
        <li>Cryptocurrency payments cannot be reversed. Once a license is activated for a 30-day period, the payment is non-refundable.</li>
        <li>If your payment was verified but your license was not activated because of a mistake on our side, we will activate it or refund the payment.</li>
        <li>If you paid the wrong amount, to the wrong network or from an exchange that deducted fees, contact support with your TXID; we will try to help but cannot guarantee recovery.</li>
        <li>Trading losses are never refundable.</li>
      </ul>
      <p>To request a review, open a support ticket or write to {telegramSupport} on Telegram.</p>
    </LegalPage>
  );
}
