"use client";
import { useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";

export default function Login() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [code, setCode] = useState("");
  const [needTotp, setNeedTotp] = useState(false);
  const [needVerify, setNeedVerify] = useState(false);
  const [error, setError] = useState("");
  const [info, setInfo] = useState("");
  const [busy, setBusy] = useState(false);
  const router = useRouter();

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError("");
    setInfo("");
    const r = await fetch("/api/auth/login", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email, password, code: code || undefined }),
    });
    const d = await r.json();
    if (!r.ok) {
      setNeedTotp(!!d.needTotp);
      setNeedVerify(!!d.needVerify);
      setError(d.error || "Login failed");
      setBusy(false);
      return;
    }
    router.push(d.role === "ADMIN" ? "/admin" : "/dashboard");
  }

  async function resend() {
    const r = await fetch("/api/auth/resend-verification", {
      method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ email }),
    });
    const d = await r.json();
    setInfo(d.message || d.error || "");
  }

  return (
    <main className="shell">
      <Link className="brand" href="/">TRADE<span>NEST</span></Link>
      <section className="panel" style={{ maxWidth: 480, margin: "60px auto" }}>
        <h1>Login</h1>
        <form className="formgrid" onSubmit={submit}>
          <input type="email" required placeholder="Email address" value={email} onChange={(e) => setEmail(e.target.value)} />
          <input type="password" required placeholder="Password" value={password} onChange={(e) => setPassword(e.target.value)} />
          {needTotp && <input inputMode="numeric" maxLength={6} placeholder="6-digit authenticator code" value={code} onChange={(e) => setCode(e.target.value)} autoFocus />}
          <button disabled={busy}>Login</button>
        </form>
        {error && <p>{error}</p>}
        {needVerify && <p><button type="button" className="secondary" onClick={resend}>Resend confirmation email</button></p>}
        {info && <div className="notice">{info}</div>}
        <p className="muted"><Link href="/forgot">Forgot password?</Link></p>
        <p className="muted">New to Trade Nest? <Link href="/register">Create account</Link></p>
      </section>
    </main>
  );
}
