import { redirect } from "next/navigation";
import { getSession } from "@/lib/session";
import { db } from "@/lib/db";
import { RENEW_WINDOW_DAYS } from "@/lib/config";
import DashboardClient from "./ui";

export default async function Dashboard() {
  const s = await getSession();
  if (!s) redirect("/login");
  const now = new Date();
  const [accounts, orders, tickets] = await Promise.all([
    db.mt5Account.findMany({ where: { userId: s.userId }, include: { licenses: { orderBy: { createdAt: "desc" }, take: 1 } }, orderBy: { createdAt: "desc" } }),
    db.order.findMany({ where: { userId: s.userId }, include: { mt5Account: true }, orderBy: { createdAt: "desc" }, take: 100 }),
    db.ticket.findMany({ where: { userId: s.userId }, orderBy: { createdAt: "desc" }, take: 50 }),
  ]);
  const rows = accounts.map((a) => {
    const lic = a.licenses[0];
    const license = !lic ? "NONE" : lic.status === "REVOKED" ? "REVOKED" : lic.expiresAt > now ? "ACTIVE" : "EXPIRED";
    const daysLeft = lic && license === "ACTIVE" ? Math.ceil((lic.expiresAt.getTime() - now.getTime()) / 86400000) : 0;
    const canSubscribe = a.status === "APPROVED" && license !== "REVOKED" && (license !== "ACTIVE" || daysLeft <= RENEW_WINDOW_DAYS);
    return {
      id: a.id, login: a.login, broker: a.broker, server: a.server, status: a.status, note: a.adminNote,
      license, expiresAt: lic?.expiresAt.toISOString() || null, daysLeft, canSubscribe,
      removable: a.status !== "APPROVED",
    };
  });
  return (
    <DashboardClient
      email={s.email}
      verified={s.verified}
      canDownload={rows.some((r) => r.license === "ACTIVE")}
      accounts={rows}
      orders={orders.map((o) => ({
        id: o.id, account: o.mt5Account.login, network: o.network, amount: o.amountUsd.toString(),
        wallet: o.walletAddress, txid: o.txid, status: o.status, note: o.adminNote, createdAt: o.createdAt.toISOString(),
      }))}
      tickets={tickets.map((t) => ({ id: t.id, subject: t.subject, status: t.status, reply: t.adminReply, createdAt: t.createdAt.toISOString() }))}
    />
  );
}
