"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";

type Account = { id: string; login: string; broker: string; server: string; status: string; note: string | null; license: string; expiresAt: string | null; daysLeft: number; canSubscribe: boolean; removable: boolean };
type Order = { id: string; account: string; network: string; amount: string; wallet: string; txid: string | null; status: string; note: string | null; createdAt: string };
type Ticket = { id: string; subject: string; status: string; reply: string | null; createdAt: string };

const badge = (s: string) => (["APPROVED", "ACTIVE", "PAID", "CLOSED"].includes(s) ? "ok" : ["REJECTED", "REVOKED", "EXPIRED"].includes(s) ? "bad" : "warn");

export default function DashboardClient({ email, verified, canDownload, accounts, orders, tickets }: {
  email: string; verified: boolean; canDownload: boolean; accounts: Account[]; orders: Order[]; tickets: Ticket[];
}) {
  const router = useRouter();
  const [msg, setMsg] = useState("");
  const [busy, setBusy] = useState(false);
  const [login, setLogin] = useState("");
  const [broker, setBroker] = useState("");
  const [server, setServer] = useState("");
  const [accountId, setAccountId] = useState("");
  const [network, setNetwork] = useState("TRC20");
  const [txids, setTxids] = useState<Record<string, string>>({});
  const [subject, setSubject] = useState("");
  const [message, setMessage] = useState("");

  async function call(url: string, body?: unknown, method = "POST") {
    const r = await fetch(url, { method, headers: { "Content-Type": "application/json" }, body: body ? JSON.stringify(body) : undefined });
    const d = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error(d.error || "Request failed");
    return d;
  }
  async function run(fn: () => Promise<string | void>) {
    setBusy(true);
    setMsg("");
    try {
      const m = await fn();
      if (m) setMsg(m);
      router.refresh();
    } catch (e: any) {
      setMsg(e.message);
    } finally {
      setBusy(false);
    }
  }
  const logout = async () => { await fetch("/api/auth/logout", { method: "POST" }); window.location.href = "/"; };
  const copy = (t: string) => navigator.clipboard?.writeText(t).then(() => setMsg("Copied."));
  const eligible = accounts.filter((a) => a.canSubscribe);

  return (
    <main className="shell">
      <header className="top">
        <a className="brand" href="/">TRADE<span>NEST</span></a>
        <div>{email} · <button className="link" onClick={logout}>Log out</button></div>
      </header>
      <h1>Customer dashboard</h1>
      <p className="muted">Manage your Gold EA accounts and monthly subscriptions.</p>
      {msg && <div className="notice">{msg}</div>}

      {!verified && (
        <div className="notice">
          Please confirm your email address to use the dashboard.{" "}
          <button className="secondary" disabled={busy} onClick={() => run(async () => { const d = await call("/api/auth/resend-verification", {}); return d.message; })}>Resend email</button>
        </div>
      )}

      {canDownload && (
        <section className="panel">
          <h2>Download the EA</h2>
          <p className="muted">Install the file in MT5 (File → Open Data Folder → MQL5 → Experts), then paste your license token into the EA inputs. Add this site under Tools → Options → Expert Advisors → Allow WebRequest.</p>
          <a href="/api/download/ea"><button>Download TradeNestGoldEA.ex5</button></a>
        </section>
      )}

      <section className="panel">
        <h2>1. Register an MT5 account</h2>
        <p className="muted">Enter the account number and the exact server name shown in MT5. Never enter your trading password or investor password.</p>
        <form className="formgrid" onSubmit={(e) => { e.preventDefault(); run(async () => { await call("/api/accounts", { login, broker, server }); setLogin(""); setBroker(""); setServer(""); return "MT5 account submitted. It will be checked manually for IB status."; }); }}>
          <input required inputMode="numeric" placeholder="MT5 account login (digits)" value={login} onChange={(e) => setLogin(e.target.value)} />
          <input required placeholder="Broker name" value={broker} onChange={(e) => setBroker(e.target.value)} />
          <input required placeholder="Exact MT5 server name" value={server} onChange={(e) => setServer(e.target.value)} />
          <button disabled={busy || !verified}>Submit for IB verification</button>
        </form>
        <div className="tablewrap">
          <table>
            <thead><tr><th>Login</th><th>Broker / Server</th><th>IB status</th><th>Subscription</th><th></th></tr></thead>
            <tbody>
              {accounts.map((a) => (
                <tr key={a.id}>
                  <td>{a.login}</td>
                  <td>{a.broker} / {a.server}</td>
                  <td><span className={`badge ${badge(a.status)}`}>{a.status}</span>{a.note ? ` — ${a.note}` : ""}</td>
                  <td>{a.license === "NONE" ? "—" : <><span className={`badge ${badge(a.license)}`}>{a.license}</span> {a.expiresAt ? new Date(a.expiresAt).toLocaleDateString() : ""}{a.license === "ACTIVE" ? ` (${a.daysLeft} days left)` : ""}</>}</td>
                  <td>{a.removable && <button className="danger" disabled={busy} onClick={() => run(async () => { await call(`/api/accounts?id=${a.id}`, undefined, "DELETE"); return "Account removed."; })}>Remove</button>}</td>
                </tr>
              ))}
            </tbody>
          </table>
          {!accounts.length && <p className="muted">No MT5 accounts submitted yet.</p>}
        </div>
      </section>

      <section className="panel">
        <h2>2. Subscribe or renew — $10 / account / 30 days</h2>
        <p className="muted">Only IB-approved accounts can subscribe. Each MT5 account needs its own payment. Renewal opens during the last 7 days of a subscription; remaining days are kept.</p>
        <form className="formgrid" onSubmit={(e) => { e.preventDefault(); run(async () => { const d = await call("/api/orders", { network, mt5AccountId: accountId }); return `Order created. Send exactly ${d.amountUsd} USDT on ${d.network} to ${d.walletAddress}, then paste the TXID below.`; }); }}>
          <select required value={accountId} onChange={(e) => setAccountId(e.target.value)}>
            <option value="">Choose approved MT5 account</option>
            {eligible.map((a) => <option key={a.id} value={a.id}>{a.login} · {a.server}</option>)}
          </select>
          <select value={network} onChange={(e) => setNetwork(e.target.value)}>
            <option value="TRC20">USDT TRC20</option>
            <option value="BEP20">USDT BEP20</option>
          </select>
          <button disabled={busy || !accountId}>Create $10 payment order</button>
        </form>
        <p className="small">Send only USDT on the selected network. Transfers on a different network may be lost. Payment is checked manually before activation.</p>
      </section>

      <section className="panel">
        <h2>3. Payments</h2>
        {orders.map((o) => (
          <div className="adminrow" key={o.id}>
            <b>MT5 {o.account}</b> · ${o.amount} · {o.network} · <span className={`badge ${badge(o.status)}`}>{o.status}</span>
            <p className="small">Order {o.id.slice(-8)} · {new Date(o.createdAt).toLocaleString()}{o.note ? ` · ${o.note}` : ""}</p>
            {o.status === "PENDING_PAYMENT" && !o.txid && (
              <>
                <p className="small">Send exactly <b>{o.amount} USDT ({o.network})</b> to:<br /><span className="mono">{o.wallet}</span> <button className="secondary" onClick={() => copy(o.wallet)}>Copy</button></p>
                <form className="formgrid" onSubmit={(e) => { e.preventDefault(); run(async () => { await call("/api/orders/submit-txid", { orderId: o.id, txid: txids[o.id] || "" }); return "TXID sent for manual verification."; }); }}>
                  <input required placeholder={o.network === "TRC20" ? "TXID (64 hex characters)" : "TXID (0x…)"} value={txids[o.id] || ""} onChange={(e) => setTxids({ ...txids, [o.id]: e.target.value })} />
                  <button disabled={busy}>Submit TXID</button>
                </form>
              </>
            )}
            {o.txid && <p className="small mono">TXID: {o.txid}</p>}
          </div>
        ))}
        {!orders.length && <p className="muted">No payments yet.</p>}
      </section>

      <section className="panel">
        <h2>Support tickets</h2>
        <form className="formgrid" onSubmit={(e) => { e.preventDefault(); run(async () => { await call("/api/tickets", { subject, message }); setSubject(""); setMessage(""); return "Support ticket submitted."; }); }}>
          <input required minLength={4} placeholder="Subject" value={subject} onChange={(e) => setSubject(e.target.value)} />
          <textarea required minLength={10} placeholder="Describe your issue" value={message} onChange={(e) => setMessage(e.target.value)} />
          <button disabled={busy}>Create support ticket</button>
        </form>
        {tickets.map((t) => (
          <div className="ticket" key={t.id}>
            <b>{t.subject}</b> · <span className={`badge ${badge(t.status)}`}>{t.status}</span>
            <p>{t.reply || "Waiting for support response"}</p>
          </div>
        ))}
      </section>
    </main>
  );
}
