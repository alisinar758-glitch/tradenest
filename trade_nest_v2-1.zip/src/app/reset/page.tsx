"use client";
import { Suspense, useState } from "react";
import Link from "next/link";
import { useSearchParams } from "next/navigation";

function ResetForm() {
  const token = useSearchParams().get("token") || "";
  const [password, setPassword] = useState("");
  const [msg, setMsg] = useState("");
  const [done, setDone] = useState(false);
  const [busy, setBusy] = useState(false);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    const r = await fetch("/api/auth/reset", {
      method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ token, password }),
    });
    const d = await r.json();
    if (r.ok) setDone(true); else setMsg(d.error || "Reset failed");
    setBusy(false);
  }

  if (done) return <div className="notice">Password changed. You were signed out everywhere. <Link href="/login">Log in</Link></div>;
  return (
    <>
      <form className="formgrid" onSubmit={submit}>
        <input type="password" minLength={10} required placeholder="New password (at least 10 characters)" value={password} onChange={(e) => setPassword(e.target.value)} />
        <button disabled={busy || !token}>Set new password</button>
      </form>
      {msg && <p>{msg}</p>}
    </>
  );
}

export default function Reset() {
  return (
    <main className="shell">
      <Link className="brand" href="/">TRADE<span>NEST</span></Link>
      <section className="panel" style={{ maxWidth: 480, margin: "60px auto" }}>
        <h1>Choose a new password</h1>
        <Suspense fallback={null}><ResetForm /></Suspense>
      </section>
    </main>
  );
}
