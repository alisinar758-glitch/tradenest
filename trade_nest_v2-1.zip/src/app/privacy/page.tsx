import LegalPage from "@/components/LegalPage";

export default function Privacy() {
  return (
    <LegalPage title="Privacy Policy">
      <h2>What we collect</h2>
      <ul>
        <li>Account data: email address and a securely hashed password.</li>
        <li>Trading account data you submit: MT5 login number, broker name and server name. We never ask for passwords of your trading account.</li>
        <li>Payment data: order details, network and the transaction hash (TXID) you submit.</li>
        <li>Support tickets and our replies.</li>
        <li>Technical data: IP address and timestamps in security and audit logs, and the time of license checks sent by the EA.</li>
      </ul>
      <h2>How we use it</h2>
      <p>To run your account, verify IB status and payments, issue and check licenses, provide support, prevent abuse and meet legal obligations. We do not sell your data.</p>
      <h2>Sharing</h2>
      <p>We may share data with service providers needed to run the site (hosting, email delivery), with your broker when verifying IB status, and with authorities when legally required.</p>
      <h2>Retention and your rights</h2>
      <p>We keep data while your account is active and as long as needed for accounting, security and legal reasons. You can ask us to correct or delete your data by opening a support ticket; some records (payments, audit logs) may have to be kept.</p>
      <h2>Security</h2>
      <p>Passwords are hashed, connections use HTTPS, administrator access requires two-factor authentication, and license tokens are stored only as hashes. No system is perfectly secure.</p>
    </LegalPage>
  );
}
