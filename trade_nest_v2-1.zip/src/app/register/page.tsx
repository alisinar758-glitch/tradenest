"use client";
import { useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";

export default function Register() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [accept, setAccept] = useState(false);
  const [error, setError] = useState("");
  const [done, setDone] = useState(false);
  const [busy, setBusy] = useState(false);
  const router = useRouter();

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError("");
    const r = await fetch("/api/auth/register", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email, password, acceptTerms: accept }),
    });
    const d = await r.json();
    if (!r.ok) { setError(d.error || "Registration failed"); setBusy(false); return; }
    if (d.verifyRequired) { setDone(true); setBusy(false); return; }
    const l = await fetch("/api/auth/login", {
      method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ email, password }),
    });
    router.push(l.ok ? "/dashboard" : "/login");
  }

  return (
    <main className="shell">
      <Link className="brand" href="/">TRADE<span>NEST</span></Link>
      <section className="panel" style={{ maxWidth: 480, margin: "60px auto" }}>
        <h1>Create account</h1>
        {done ? (
          <div className="notice">We sent a confirmation link to <b>{email}</b>. Open it to activate your account, then <Link href="/login">log in</Link>. Check your spam folder if you do not see it.</div>
        ) : (
          <form className="formgrid" onSubmit={submit}>
            <input type="email" required placeholder="Email address" value={email} onChange={(e) => setEmail(e.target.value)} />
            <input type="password" minLength={10} required placeholder="Password (at least 10 characters)" value={password} onChange={(e) => setPassword(e.target.value)} />
            <label className="checkrow">
              <input type="checkbox" checked={accept} onChange={(e) => setAccept(e.target.checked)} required />
              <span>I have read and accept the <Link href="/terms">Terms</Link>, <Link href="/privacy">Privacy Policy</Link>, <Link href="/risk">Risk Disclosure</Link> and <Link href="/refund">Refund Policy</Link>.</span>
            </label>
            <button disabled={busy || !accept}>Create account</button>
          </form>
        )}
        {error && <p>{error}</p>}
        <p className="muted">Already registered? <Link href="/login">Login</Link></p>
      </section>
    </main>
  );
}
