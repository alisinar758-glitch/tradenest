import LegalPage from "@/components/LegalPage";
import { telegramSupport } from "@/lib/config";

export default function Terms() {
  return (
    <LegalPage title="Terms of Service">
      <h2>1. The service</h2>
      <p>Trade Nest sells time-limited licenses to use an automated trading program (Expert Advisor, "EA") for XAUUSD on MetaTrader 5. We do not manage your money, do not hold your funds and do not provide investment advice.</p>
      <h2>2. Eligibility and IB requirement</h2>
      <p>You must be an adult and legally allowed to trade in your country. Each MT5 account you use must be opened under our Introducing Broker (IB) link and is verified manually. We may refuse or withdraw approval of an account at any time.</p>
      <h2>3. Subscription and license</h2>
      <ul>
        <li>Price: USD 10 per MT5 account per 30 days. Each account needs its own subscription.</li>
        <li>A license is tied to one MT5 login and one broker server. It is personal, non-transferable and may not be shared, resold or copied.</li>
        <li>When a subscription ends or is revoked, the EA stops opening new trades. Existing positions are not closed by the license system; you are responsible for managing them.</li>
      </ul>
      <h2>4. Payment</h2>
      <p>Payments are made in USDT on TRC20 or BEP20 to the wallet shown in your dashboard. Send only USDT on the selected network. Transfers on the wrong network or to a wrong address may be lost and are not our responsibility. Payments are checked manually and activation may take some time.</p>
      <h2>5. Acceptable use</h2>
      <p>Do not attempt to bypass, reverse engineer or share the license system or the EA file. Never send us your trading or investor password. We may suspend licenses for abuse.</p>
      <h2>6. No guarantee, limitation of liability</h2>
      <p>Trading carries a high risk of loss. Past or simulated results do not guarantee future results. The service is provided "as is". To the maximum extent permitted by law, Trade Nest is not liable for trading losses, missed profits, broker or network outages, or indirect damages. Our total liability is limited to the amount you paid for the current subscription period.</p>
      <h2>7. Changes and termination</h2>
      <p>We may update the EA, the website and these terms. Continued use means you accept the updated terms. We may terminate accounts that violate these terms.</p>
      <h2>8. Contact</h2>
      <p>Support: open a ticket in your dashboard or contact {telegramSupport} on Telegram.</p>
    </LegalPage>
  );
}
