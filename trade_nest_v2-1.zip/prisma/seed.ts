import { PrismaClient } from "@prisma/client";

const db = new PrismaClient();

async function main() {
  await db.product.upsert({
    where: { slug: "gold-ea" },
    update: { priceUsd: 10, durationDays: 30, symbol: "XAUUSD", active: true },
    create: { slug: "gold-ea", name: "Trade Nest Gold EA", symbol: "XAUUSD", priceUsd: 10, durationDays: 30, version: "1.0.0" },
  });
}

main().finally(() => db.$disconnect());
