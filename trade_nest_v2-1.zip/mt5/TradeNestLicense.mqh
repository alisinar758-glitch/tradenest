//+------------------------------------------------------------------+
//| TradeNestLicense.mqh                                             |
//| Server-side license check for Trade Nest EAs.                    |
//|                                                                  |
//| HOW TO USE (3 lines in your EA):                                 |
//|   #include "TradeNestLicense.mqh"            // top of the EA     |
//|   OnInit():   if(!TN_Init()) return INIT_FAILED;  (or INIT_SUCCEEDED and just block trading) |
//|   OnTimer():  TN_Timer();     // EventSetTimer(60) is done by TN_Init() |
//|   Before every NEW entry:  if(!TN_AllowNewTrades()) return;      |
//|                                                                  |
//| Existing positions are NEVER closed by this file.                |
//| In MT5: Tools > Options > Expert Advisors > Allow WebRequest for |
//| listed URL > add your site, e.g. https://tradenest.net           |
//+------------------------------------------------------------------+
#property strict

input group "=== Trade Nest license ==="
input string TN_LicenseApi        = "https://tradenest.net/api/license/validate"; // License API URL
input string TN_LicenseToken      = "";    // License token from your dashboard / email
input int    TN_CheckEveryMinutes = 60;    // How often to re-check the license
input int    TN_OfflineGraceHours = 24;    // Keep trading this long if the server is unreachable
input bool   TN_AllowInTester     = true;  // Skip the license check in the Strategy Tester

bool     g_tnValid     = false;
datetime g_tnLastOk    = 0;   // last time the server said "valid"
datetime g_tnLastCheck = 0;
string   g_tnReason    = "NOT_CHECKED";

string TN_Escape(string s)
{
   StringReplace(s, "\\", "\\\\");
   StringReplace(s, "\"", "\\\"");
   return s;
}

// Returns: 1 = server says valid, 0 = server says invalid, -1 = could not reach the server
int TN_Query()
{
   string body = "{\"token\":\"" + TN_Escape(TN_LicenseToken) + "\","
               + "\"login\":\"" + (string)AccountInfoInteger(ACCOUNT_LOGIN) + "\","
               + "\"server\":\"" + TN_Escape(AccountInfoString(ACCOUNT_SERVER)) + "\","
               + "\"symbol\":\"" + TN_Escape(_Symbol) + "\"}";
   char data[], result[];
   int n = StringToCharArray(body, data, 0, StringLen(body), CP_UTF8);
   ArrayResize(data, n);
   string headers = "Content-Type: application/json\r\n";
   string resHeaders;
   ResetLastError();
   int code = WebRequest("POST", TN_LicenseApi, headers, 8000, data, result, resHeaders);
   if(code == -1)
   {
      g_tnReason = "WEBREQUEST_ERROR_" + (string)GetLastError() + " (add the URL to Allow WebRequest)";
      return -1;
   }
   string resp = CharArrayToString(result, 0, -1, CP_UTF8);
   if(code == 429 || code >= 500) { g_tnReason = "SERVER_HTTP_" + (string)code; return -1; }
   int p = StringFind(resp, "\"reason\":\"");
   g_tnReason = "UNKNOWN";
   if(p >= 0)
   {
      int s = p + 10;
      int e = StringFind(resp, "\"", s);
      if(e > s) g_tnReason = StringSubstr(resp, s, e - s);
   }
   if(code == 200 && StringFind(resp, "\"valid\":true") >= 0) return 1;
   return 0;
}

void TN_Check()
{
   g_tnLastCheck = TimeLocal();
   int r = TN_Query();
   if(r == 1)      { g_tnValid = true; g_tnLastOk = TimeLocal(); }
   else if(r == 0) { g_tnValid = false; }                 // server answered: not allowed -> block immediately
   else            // network problem: allow only inside the offline grace window
      g_tnValid = (g_tnLastOk > 0 && (TimeLocal() - g_tnLastOk) <= TN_OfflineGraceHours * 3600);
   Comment("Trade Nest license: ", g_tnValid ? "ACTIVE" : "BLOCKED", " (", g_tnReason, ")");
   if(!g_tnValid) Print("Trade Nest license blocked new trades: ", g_tnReason);
}

bool TN_Init()
{
   if(MQLInfoInteger(MQL_TESTER) && TN_AllowInTester) { g_tnValid = true; return true; }
   if(StringLen(TN_LicenseToken) < 20) { Print("Trade Nest: paste your license token in the EA inputs."); }
   EventSetTimer(60);
   TN_Check();
   return true;   // never fail OnInit: the EA keeps managing open positions even when blocked
}

void TN_Timer()
{
   if(MQLInfoInteger(MQL_TESTER) && TN_AllowInTester) return;
   if(TimeLocal() - g_tnLastCheck >= TN_CheckEveryMinutes * 60) TN_Check();
}

bool TN_AllowNewTrades()
{
   if(MQLInfoInteger(MQL_TESTER) && TN_AllowInTester) return true;
   return g_tnValid;
}
