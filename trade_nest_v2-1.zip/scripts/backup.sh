#!/bin/sh
# Daily database backup. Add to cron:  0 3 * * * cd /path/to/trade-nest && ./scripts/backup.sh
set -e
mkdir -p backups
FILE="backups/tradenest-$(date +%F).sql.gz"
docker compose exec -T db pg_dump -U postgres tradenest | gzip > "$FILE"
find backups -name 'tradenest-*.sql.gz' -mtime +14 -delete
echo "Backup saved: $FILE (copy it off the server too!)"
