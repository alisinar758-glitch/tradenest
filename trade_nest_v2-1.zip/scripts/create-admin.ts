import { PrismaClient } from "@prisma/client";
import bcrypt from "bcryptjs";

// Usage: set ADMIN_EMAIL and ADMIN_PASSWORD in .env (or the shell), then run: npm run admin:create
const db = new PrismaClient();

async function main() {
  const email = (process.env.ADMIN_EMAIL || "").trim().toLowerCase();
  const password = process.env.ADMIN_PASSWORD || "";
  if (!email || password.length < 12) {
    throw new Error("Set ADMIN_EMAIL and an ADMIN_PASSWORD of at least 12 characters.");
  }
  const passwordHash = await bcrypt.hash(password, 12);
  await db.user.upsert({
    where: { email },
    update: { role: "ADMIN", passwordHash, emailVerifiedAt: new Date(), tokenVersion: { increment: 1 } },
    create: { email, passwordHash, role: "ADMIN", emailVerifiedAt: new Date(), termsAcceptedAt: new Date() },
  });
  console.log(`Admin ready: ${email}. Log in, then set up two-factor authentication at /admin/security.`);
}

main()
  .catch((e) => { console.error(e.message); process.exit(1); })
  .finally(() => db.$disconnect());
